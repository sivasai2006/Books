from pyspark.sql import SparkSession
from pyspark.streaming import StreamingContext

checkpointDir = "/hadoop/prodtest/tips/clickstreams/sample/checkpoint/"

def createStreamingContext():
    spark = SparkSession \
        .builder \
        .appName("CheckpointStreaming") \
        .config("spark.debug.maxToStringFields", 100) \
        .getOrCreate()

    sc = spark.sparkContext
    ssc = StreamingContext(sc, 30)
    ssc.checkpoint(checkpointDir)

    return ssc


def process(time, rdd):
    #print("========= %s =========" % str(time))
    try:
        # Get the singleton instance of SparkSession
        spark = getSparkSessionInstance(rdd.context.getConf())

        # Convert RDD[String] to RDD[Row] to DataFrame
        rowRdd = rdd.map(lambda w: Row(word=w))
        wordsDataFrame = spark.createDataFrame(rowRdd)

        # Creates a temporary view using the DataFrame
        wordsDataFrame.createOrReplaceTempView("words")

        # Do word count on table using SQL and print it
        wordCountsDataFrame = spark.sql("select word as total from words")
        wordCountsDataFrame.show()

        wordCountsDataFrame.saveAsTextFiles("/hadoop/prodtest/tips/clickstreams/sample/output/")

    except:
        pass

if __name__ == "__main__":

    #ssc = createStreamingContext(checkpointDir)
    ssc = StreamingContext.getOrCreate(checkpointDir, createStreamingContext)

    json_rdd = ssc.textFileStream("/hadoop/prodtest/tips/clickstreams/sample/data/")

    #json_rdd.cache()
    #json_rdd.checkpoint(30)

    json_rdd.pprint()

    json_rdd.foreachRDD(process)

    #json_rdd.saveAsTextFiles("/hadoop/prodtest/tips/clickstreams/sample/output/")

    ssc.start()
    ssc.awaitTermination()
